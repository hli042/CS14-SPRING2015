#ifndef BST_H
#define BST_H
#define TEST

#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <algorithm>
#include <cstring>
#include <map>
using namespace std;
#define nil 0

template <typename Value>
class BST
{
    class Node {
        public:
            Node *left;
            Node *right;
            Value value;
            bool selected;
            Node (const Value v)
            {
                value = v;
                left = nil;
                right = nil;
                selected = false;
            }
            Value& content() { return value; }
            bool isInternal() { return ((left != nil) && (right != nil)); }
            bool isExternal() { return ((left != nil) || (right != nil)); }
            bool isLeaf() { return ((left == nil) && (right == nil)); }
            
            int height()
            {
                if (this == nil) return 0;
                else return (1 + max(this->left->height(), this->right->height()));
            }
            int size()
            {
                if (this == nil) return 0;
                else return (1 + this->left->size() + this->right->size());
            }
    };
    
    public:
        Node *root;
        int count;
        BST()
        {
            root = nil;
            count = 0;
        }
        int size()
        {
            return root->size();
        }
        bool empty()
        {
            if (root->size() == 0) return true;
            else return false;
        }
        void print_node(const Node *n)
        {
            cout << n->content() << endl;
        }
        bool search(Value x)
        {
            Node *a = root;
            while ((a != nil) && (a->value != x))
            {
                if (x > a->value) a = a->right;
                else a = a->left;
            }
            if (a->value == x) return true;
            else return false;
        }
        void preorder() const { preorderprint(root); }
        void preorderprint(Node *a) const
        {
            if (a == nil) return;
            cout << a->value << " ";
            preorderprint(a->left);
            preorderprint(a->right);
        }
        void postorder() const { postorderprint(root); }
        void postorderprint(Node *a) const
        {
            if (a == nil) return;
            postorderprint(a->left);
            postorderprint(a->right);
            cout << a->value << " ";
        }
        void inorder() const { inorderprint(root); }
        void inorderprint(Node *a) const
        {
            if (a == nil) return;
            inorderprint(a->left);
            cout << a->value << " ";
            inorderprint(a->right);
        }
        Value& operator[] (int n)
        {
            if ((n > this->size()) || (n < 0))
            {
                cout << " error parameter n" << endl;
                exit(1);
            }
            return inordersearch(root, n);
            
        }
        Value& inordersearch(Node *a, int n)
        {
            if (a == nil) exit(1);
            int num_left = a->left->size();
            if (num_left == n) return a->value;
            else if (num_left > n) return inordersearch(root->left, n);
            else return inordersearch(root->right, n - num_left - 1);
        }
        void insert(Value X) { root = insert(X, root); }
        Node *insert( Value X, Node *T)
        {
            if (T == nil)
            {
                T = new Node(X);
            }
            else if (X < T->value)
            {
                T->left = insert(X, T->left);
            }
            else if (X > T->value)
            {
                T->right = insert(X, T->right);
            }
            else T->value = X;
            return T;
        }
        void remove(Value X) { root = remove(X, root); }
        Node *remove(Value X, Node*& T)
        {
            if (T != nil)
            {
                if (X > T->value) T->right = remove(X, T->right);
                else if (X < T->value) T->left = remove(X, T->left);
                else 
                {
                    if (T->right != nil)
                    {
                        Node* x = T->right;
                        while(x->left != nil) x = x->left;
                        T->value = x->value;
                        T->right = remove(T->value, T->right);
                    }
                    else if (T->left != nil)
                    {
                        Node *x = T->left;
                        while (x->right != nil) x = x->right;
                        T->value = x->value;
                        T->left = remove(T->value, T->left);
                    }
                    else
                    {
                        delete T;
                        T = nil;
                    }
                }
            }
            return T;
        }
        void minCover() { minCover(root); }
        void minCover(Node* T)
        {
            if (T != nil)
            {
                if (T->isLeaf() || (T == root)) T->selected = false;
                else 
                {
                    T->selected = true;
                    count++;
                }    
                minCover(T->left);
                minCover(T->right);
            }
        }
        void displayMinCover()
        {
            minCoverprint(root);
            cout << endl << count << endl;
        }
        void minCoverprint(Node *a) const
        {
            if (a == nil) return;
            minCoverprint(a->left);
            if (a->selected)
            cout << a->value << " ";
            minCoverprint(a->right);
        }
        
        void findSumPath(Node *n, int sum, int buffer[])
        {
            if (n == nil) return;
            buffer[getlevel(n->value) - 1] = n->value;
            if (n->isLeaf()) pathprint(sum, n, buffer);
            else
            {
                findSumPath(n->left, sum, buffer);
                findSumPath(n->right, sum, buffer);
            }
        }
        int getlevel(Node *n, int data, int level)
        {
            if (n == nil) return 0;
            if (n->value == data) return level;
            int downlevel = getlevel(n->left, data, level+1);
            if (downlevel != 0) return downlevel;
            downlevel = getlevel(n->right, data, level+1);
            return downlevel;
        }
        int getlevel(int data) { return getlevel(root, data, 1); }
        void pathprint(int sum, Node *n, int buffer[])
        {
            int currentsum = 0;
            for (int i = 0; i < getlevel(n->value); ++i)
            {
                currentsum = currentsum + buffer[i];
            }
            if (currentsum == sum)
            {
                for (int i = 0; i < getlevel(n->value); ++i)
                {
                    for (int j = i + 1; j < getlevel(n->value); ++j)
                    {
                        if (buffer[j] < buffer[i])
                        {
                            int tp = buffer[i];
                            buffer[i] = buffer[j];
                            buffer[j] = tp;
                        }
                    }
                }
                for (int j = 0; j < getlevel(n->value); ++j)
                {
                    cout << buffer[j] << " ";
                }
                cout << endl;
            }
        }
        
        void vertSumtil(Node *node, int hd, map<int, int>& m)
        {
            if (node == nil) return;
            vertSumtil(node->left, hd-1, m);
            m[hd] = m[hd] + node->value;
            vertSumtil(node->right, hd+1, m);
        }
        void vertSum(Node *node, int hd, map<int, int>& m)
        {
            if (node == nil) return;
            vertSumtil(node, hd, m);
            for (map<int, int>::iterator i = m.begin(); i != m.end(); ++i){
                cout << i->second << " ";
            }
            cout << endl;
        }
};

#endif
