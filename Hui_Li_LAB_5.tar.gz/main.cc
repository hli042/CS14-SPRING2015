#include "bst.h"
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <algorithm>
#include <cstring>
using namespace std;
#define nil 0
#define TEST

int main()
{
    BST<int> bst;
    bst.insert(50);
    bst.insert(20);
    bst.insert(10);
    bst.insert(40);
    bst.insert(35);
    bst.insert(45);
    bst.insert(60);
    bst.insert(70);
    bst.minCover();
    bst.displayMinCover();
    
    int *buffer;
    buffer = new int[100];
    bst.findSumPath(bst.root, 80, buffer);
    map<int, int> m;
    bst.vertSum(bst.root, 0, m);
    
    return 0;
}