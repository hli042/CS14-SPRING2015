My selection sort is not astable selection.

a. For example, the list is 1 5(first) 2 3 5(second) 1. After sorting, last 1 
exchanges with the first 5 and the list will be 1 1 2 3 5(second) 5(first).

b. As shown above, I can use function to sort the list (1, 1) (5, 1) (2, 1) 
(3, 1) (5, 2) (1, 2), which the second element in pair is mark of same 
element's order and see the result.