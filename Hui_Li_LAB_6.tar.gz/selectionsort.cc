#include <iostream>
#include <algorithm>
#include <list>
#include <utility>
#include <vector>

using namespace std;

template <typename L>
void selectionsort(L &l)
{
    typename L::iterator m;
    int move = 0;
    for (auto i = l.begin(); i != l.end(); ++i){
        m = i;
        for (auto j = i; j != l.end(); ++j){
            if (*j < *i) m = j;
        }
        if (i != m)
        {
            swap(*i, *m);
            move = move + 3;
        }
    }
    cout << "Sorting completed, 0 copies and " << move << " moves" << endl;
}

int main()
{
    vector<int> a;
    a.push_back(2);
    a.push_back(4);
    a.push_back(5);
    a.push_back(1);
    a.push_back(8);
    a.push_back(9);
    cout << "pre:  ";
    for(auto i = a.begin(); i != a.end(); ++i) {
        cout << *i << " ";
    }
    cout << endl;
    selectionsort(a);
    cout << "post: ";
    for(auto i = a.begin(); i != a.end(); ++i) {
        cout << *i << " ";
    }
    cout << endl << endl;

    typedef pair<int, int> Pair;
    list<Pair> b;
    b.push_back(make_pair(1, 2));
    b.push_back(make_pair(3, -1));
    b.push_back(make_pair(-1, 3));
    b.push_back(make_pair(0, 0));
    b.push_back(make_pair(2, 3));
    b.push_back(make_pair(1, 2));
    b.push_back(make_pair(1, -2));
    b.push_back(make_pair(8, 10));
    cout << "pre:  ";
    for(auto i = b.begin(); i != b.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl;
    selectionsort(b);
    cout << "post: ";
    for(auto i = b.begin(); i != b.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl << endl;
    
    list<Pair> c;
    c.push_back(make_pair(10, 2));
    c.push_back(make_pair(-3, -1));
    c.push_back(make_pair(-8, 0));
    c.push_back(make_pair(1, 1));
    c.push_back(make_pair(1, 1));
    c.push_back(make_pair(0, 0));
    c.push_back(make_pair(10, 2));
    c.push_back(make_pair(5, 5));
    c.push_back(make_pair(5, -5));
    c.push_back(make_pair(0, 0));
    c.push_back(make_pair(10, 2));
    cout << "pre:  ";
    for(auto i = c.begin(); i != c.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl;
    selectionsort(c);
    cout << "post: ";
    for(auto i = c.begin(); i != c.end(); ++i) {
        cout << "(" << i->first << ", " << i->second << ") ";
    }
    cout << endl << endl;
}