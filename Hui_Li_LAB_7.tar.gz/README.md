//Hui Li
//ID: 605715
//LAB7

1.    Trees
    Advantage: allow range search efficiently and the direct iteration on subsets based on their order.
    Disadvantage: Trees are generally slower than hashtable to insert elements and access individual elements by their key.
2.    Hashtable:
    Advantage: hashtable is quicker for inserting and searching.
    Disadvantage: can't do iteration for all elements.

Trees are memory-efficient. They don't reserve more memory than they need to.