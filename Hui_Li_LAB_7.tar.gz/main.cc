//Hui Li
//ID: 605715
//LAB7

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <set>
#include <unordered_set>
#include <ctime>

using namespace std;

int main()
{
    string word;
    vector<string> words;
    ifstream infile;
    ofstream dataout;
    clock_t t1;
    clock_t t2;
    clock_t t3;
    clock_t t4;
    
    infile.open("words.txt");
    dataout.open("data.txt", ios::trunc);
    while(infile >> word)
    {
        words.push_back(word);
    }
    
    set<string> bstree;
    unordered_set<string> hashtable;
    for (int n = 5000; n < 50000; n+=5000){
        t1 = clock();
        for(int i = 0; i < n; ++i){
            bstree.insert(words[i]);
        }
        t1 = clock() - t1;
        
        t2 = clock();
        for(int i = 0; i < n; ++i){
            bstree.find(words[i]);
        }
        t2 = (clock() - t2);
        
        t3 = clock();
        for(int i = 0; i < n; ++i){
            hashtable.insert(words[i]);
        }
        t3 = clock() - t3;
        
        t4 = clock();
        for(int i = 0; i < n; ++i){
            hashtable.find(words[i]);
        }
        t4 = (clock() - t4);
        
        dataout << n << " " << 1000*((float)t1)/CLOCKS_PER_SEC << " " 
                            << 1000*((float)t3)/CLOCKS_PER_SEC << " " 
                            << 1000*((float)t2)/CLOCKS_PER_SEC/n << " " 
                            << 1000*((float)t4)/CLOCKS_PER_SEC/n << endl;
        bstree.clear();
        hashtable.clear();
    }
    dataout.close();
    return 0;
}