#include "lab3.h"
#include <iostream>
#include <stack>
using namespace std;

int main()
{
    TwoStackFixed<int> temp1(10, 7); //class TwoStackFixed test
    int j = temp1.isEmptyStack1();
    int i = temp1.isEmptyStack2();
    cout << j << " " << i << endl;
    
    temp1.pushStack1(10);
    temp1.pushStack2(7);
    temp1.pushStack2(6);
    temp1.pushStack2(0);
    j = temp1.isFallStack1();
    i = temp1.isFallStack2();
    cout << j << " " << i << endl;
    
    temp1.pushStack2(3);
    int a = temp1.popStack1();
    int b = temp1.popStack2();
    cout << a << " " << b << endl;
    // temp1.popStack1();
    
    TwoStackOptimal<int> temp2(10); //class TwoStackOptimal test
    temp2.pushFlexStack1(10);
    temp2.pushFlexStack1(10);
    temp2.pushFlexStack1(10);
    temp2.pushFlexStack1(10);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(5);
    temp2.pushFlexStack2(7);
    temp2.popFlexStack1();
    temp2.popFlexStack1();
    temp2.popFlexStack1();
    temp2.popFlexStack1();
    // temp2.popFlexStack1();
    
    stack<int> A, B, C;
    A.push(1);
    A.push(2);
    A.push(3);
    A.push(4);
    A.push(5);
    A.push(6);
    showTowerStates(6, A, B, C);
    cout << C.top() << endl;
    printStates(6, 'A', 'B', 'C');
    
    
    return 0;
}