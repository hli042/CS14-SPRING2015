// Name: Hui Li
// SID: 605715
// Date: April 27, 2015

#ifndef __LAB3_H__
#define __LAB3_H__

#include <iostream>
#include <stack>
using namespace std;

template <typename T>
class TwoStackFixed
{
    private:
        T *stack_arr;
        int stack1;
        int stack2;
        int curr1;
        int curr2;
    public:
        TwoStackFixed(int size, int maxtop)
        {
            stack_arr = new T[size];
            stack1 = maxtop;
            stack2 = size - maxtop;
            curr1 = 0;
            curr2 = 0;
        }
        void pushStack1(T value)
        {
            if ((curr1 >= stack1) && (curr1 < 0)) 
            {
                cout << "stack overflow or underflow" << endl;
                return;
            }
            stack_arr[curr1] = value;
            curr1 = curr1 + 1;
            display1();
        }
        void pushStack2(T value)
        {
            if (curr2 >= stack2 )
            {
                cout << "stack overflow or underflow" << endl;
                return;
            }
            stack_arr[stack1 + stack2 - curr2 - 1] = value;
            curr2 = curr2 + 1;
            display2();
        }
        T popStack1()
        {
            if (curr1 == 0)
            {
                cout << "Error pop, stack is empty and program is quit." << endl;
                exit(1);
            }
            else
            {
                T data = stack_arr[curr1 - 1];
                stack_arr[curr1 - 1] = '\0';
                curr1 = curr1 - 1;
                return data;
            }
        }
        T popStack2()
        {
            if (curr2 == 0)
            {
                cout << "Error pop, stack is empty and program is quit" << endl;
                exit(1);
            }
            else
            {
                T data = stack_arr[stack1 + stack2 - curr2];
                stack_arr[stack1 + stack2 - curr2] = '\0';
                curr2 = curr2 - 1;
                return data;
            }
        }
        bool isFallStack1()
        {
            if (curr1 == stack1) return true;
            else return false;
        }
        bool isFallStack2()
        {
            if (curr2 == stack2) return true;
            else return false;
        }
        bool isEmptyStack1()
        {
            if (curr1 == 0) return true;
            else return false;
        }
        bool isEmptyStack2()
        {
            if (curr2 == 0) return true;
            else return false;
        }
        void display1()
        {
            if (isEmptyStack1())
            {
                cout << "empty stack" << endl;
                return;
            }
            cout << "stack1: ";
            for (int i = 0; i < curr1; ++i){
                cout << stack_arr[i] << " ";
            }
            cout << endl;
        }
        void display2()
        {
            if (isEmptyStack2())
            {
                cout << "empty stack" << endl;
                return;
            }
            cout << "stack2: ";
            for (int i = 0; i < curr2; ++i){
                cout << stack_arr[stack1 + stack2 - i - 1] << " ";
            }
            cout << endl;
        }
};

template <typename T>
class TwoStackOptimal
{
    private:
        T* stack_arr;
        int size;
        int curr1;
        int curr2;
    public:
        TwoStackOptimal(int size)
        {
            stack_arr =  new T[size];
            this->size = size;
            curr1 = 0;
            curr2 = 0;
        }
        void pushFlexStack1(T value)
        {
            if ((curr1 + curr2) >= size)
            {
                cout << "Stack is overflow" << endl;
                return;
            }
            stack_arr[curr1] = value;
            curr1 = curr1 + 1;
            display1();
        }
        void pushFlexStack2(T value)
        {
            if ((curr1 + curr2) >= size)
            {
                cout << "Stack is overflow" << endl;
                return;
            }
            stack_arr[size - curr2 - 1] = value;
            curr2 = curr2 + 1;
            display2();
        }
        T popFlexStack1()
        {
            if (curr1 == 0)
            {
                cout << "Error pop, stack is underflow" << endl;
                exit(1);
            }
            else
            {
                T data = stack_arr[curr1 - 1];
                stack_arr[curr1 - 1] = '\0';
                curr1 = curr1 - 1;
                return data;
            }
        }
        T popFlexStack2()
        {
            if (curr2 == 0)
            {
                cout << "Error pop, stack is underflow" << endl;
                exit(1);
            }
            else
            {
                T data = stack_arr[size - curr2];
                stack_arr[size - curr2] = '\0';
                curr2 = curr2 - 1;
                return data;
            }
        }
        bool isFallStack1()
        {
            if ((curr1 + curr2) >= size) return true;
            else return false;
        }
        bool isFallStack2()
        {
            if ((curr1 + curr2) >= size) return true;
            else return false;
        }
        bool isEmptyStack1()
        {
            if (curr1 == 0) return true;
            else return false;
        }
        bool isEmptyStack2()
        {
            if (curr2 == 0) return true;
            else return false;
        }
        void display1()
        {
            if (isEmptyStack1())
            {
                cout << "empty stack" << endl;
                return;
            }
            cout << "stack1: ";
            for (int i = 0; i < curr1; ++i){
                cout << stack_arr[i] << " ";
            }
            cout << endl;
        }
        void display2()
        {
            if (isEmptyStack2())
            {
                cout << "empty stack" << endl;
                return;
            }
            cout << "stack2: ";
            for (int i = 0; i < curr2; ++i){
                cout << stack_arr[size - i - 1] << " ";
            }
            cout << endl;
        }
};

#endif

template <typename T>
void showTowerStates(int n, stack<T> &A, stack<T> &B, stack<T> &C)
{
    if (n == 1) 
    {
        T value = A.top();
        A.pop();
        C.push(value);
        // cout << "Moved " << value << "from peg A to C" << endl;
        return;
    }
    showTowerStates(n - 1, A, C, B);
    T value = A.top();
    A.pop();
    C.push(value);
    // cout << "Moved " << value << "from peg A to C" << endl;
    showTowerStates(n - 1, B, A, C);
}

void printStates(int n, char A, char B, char C)
{
    if (n > 0)
    {
        printStates(n - 1, A, C, B);
        cout << "Moved " << n << " from peg " << A << " to peg " << C << endl;
        printStates(n - 1, B, A, C);
    }
}