// Name: Hui Li
// SID: 605715
// Date: April 19, 2015

#include <iostream>
#include "lab4.h"
#include <queue>
using namespace std;

int main(int argc, char* argv[])
{
    int k = strtol(argv[1], 0, 10);
    cout << "preorder: " << endl;
    preorder(2, 1, k);
    preorder(3, 1, k);
    cout << "postorder: " << endl;
    postorder(2, 1, k);
    postorder(3, 1, k);
    cout << "inorder: " << endl;
    inorder(k);
    return 0;
}