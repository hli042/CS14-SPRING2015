#ifndef LAB4_H
#define LAB4_H
#include <iostream>
#include <queue>
#include <stack>
using namespace std;

void preorder(int m, int n, int k)
{
    if ((m + n) > k) return;
    cout << m << " " << n << endl;
    preorder(2*m - n, m, k);
    preorder(2*m + n, m, k);
    preorder(m + 2*n, n, k);
}

void postorder(int m, int n, int k)
{
    if ((m + n) > k) return;
    postorder(2*m - n, m, k);
    postorder(2*m + n, m, k);
    postorder(m + 2*n, n, k);
    cout << m << " " << n << endl;
}

typedef pair<int, int> mypair;
void inorderadd(int m, int n, int k, priority_queue<mypair> &print)
{
    if((m + n) > k) return;
    mypair temp(m, n);
    print.push(temp);
    inorderadd(2*m - n, m, k, print);
    inorderadd(2*m + n, m, k, print);
    inorderadd(m + 2*n, n, k, print);
}

void inorder(int k)
{
    priority_queue<mypair> a;
    inorderadd(2, 1, k, a);
    inorderadd(3, 1, k, a);
    mypair temp;
    stack<mypair> b;
    while(!a.empty())
    {
        temp = a.top();
        b.push(temp);
        a.pop();
    }
    while (!b.empty())
    {
        temp = b.top();
        cout << temp.first << ' ' << temp.second << endl;
        b.pop();
    }
}


#endif