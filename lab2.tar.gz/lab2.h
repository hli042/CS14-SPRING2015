// Name: Hui Li
// SID: 605715
// Date: April 19, 2015

#ifndef __LAB2_H__
#define __LAB2_H__

#include <iostream>
#include <forward_list>

using namespace std;

template <typename Type>
class Node
{
    public:
        Node<Type>(Type data): data(data), next(0) {}
        Type data;
        Node<Type> *next;
};

template <typename Type>
class List
{
    private:
        Node<Type> *head;
        Node<Type> *tail;
        int size;
    public:
        List(): head(0), tail(0), size(0)
        {}
        ~List()
        {
            while(head != 0)
            {
                pop_front();
            }
        }

        void pop_front()
        {
            if (head == 0) return;
            Node<Type> *temp = head;
            head = head->next;
            delete temp;
            if (head == 0) tail = 0;
            size = size - 1;
        }

        void push_back(Type data)
        {
            if(head == 0)
            {
                head = new Node<Type>(data);
                tail = head;
                ++size;
            }
            else
            {
                Node<Type> *temp = new Node<Type>(data);
                tail->next = temp;
                tail = temp;
                ++size;
            }
        }

        void elementSwap(int pos)
        {
            if ((pos + 2 <= size) && (pos >= 0))
            {
                Node<Type> *b;
                Node<Type> *a = head;
                for(int i = 0; i < (pos - 1); ++i){
                    a = a->next;
                }
                b = a->next;
                a->next = a->next->next;
                b->next = a->next->next;
                a->next->next = b;
            }
            else
            {
                cout << "error parameter" << endl;
            }
        }

        void print()
        {
            if (head == 0) return;
            for (Node<Type> *i = head; i != 0; i = i->next){
                cout << i->data << " ";
            }
            cout << endl;
        }
        
};
#endif

template <typename Type>
void listCopy(forward_list<Type> L, forward_list<Type> &P)
{
    Type temp;
    forward_list<Type> a;
    typename forward_list<Type>::iterator i, j;
    while(!P.empty())
    {
        temp = P.front();
        a.push_front(temp);
        P.pop_front();
    }
    for (i = L.begin(); i != L.end(); ++i){
        P.push_front(*i);
    }
    for (j = a.begin(); j != a.end(); ++j){
        P.push_front(*j);
    }
}

template <typename Type>
void printLots(forward_list<Type> L, forward_list<int> P)
{
    forward_list<int>::iterator i;
    typename forward_list<Type>::iterator j;
    for (i = P.begin(); i != P.end(); ++i){
        j = L.begin();
        for (int a = 0; a < (*i); ++a){
            ++j;
        }
        cout << *j << " ";
    }
    cout << endl;
}

