// Name: Hui Li
// SID: 605715
// Date: April 19, 2015

#include <iostream>
#include "lab2.h"
#include <forward_list>
#include <cmath>
using namespace std;

bool isPrime(int i)
{
    if (i <= 1) return false;
    else if (i == 2) return true;
    else if (i % 2 == 0) return false;
    else
    {
        bool prime = true;
        int divisor = 3;
        double inew = static_cast<double>(i);
        int upper = static_cast<int>(sqrt(inew) + 1);
        while (divisor <= upper)
        {
            if (i % divisor == 0) prime = false;
            divisor += 2;
        }
        return prime;
    }
}

int primeCount(forward_list<int> lst)
{
    forward_list<int> temp = lst;
    if (temp.empty())
    {
        return 0;
    }
    if(isPrime(*temp.begin()))
    {
        temp.pop_front();
        return (primeCount(temp) + 1);
    }
    else 
    {
        temp.pop_front();
        return primeCount(temp);
    }
}

template <typename Type>
forward_list<Type> listcopy(forward_list<Type> L, forward_list<Type> P)
{
    while(!P.empty())
    {
        P.pop_front();
    }
    for (auto i = L.begin(); i != L.end(); ++i){
        P.push_front(*i);
    }
    return P;
}

int main()
{
    List<int> list1;
    List<int> list2;
    list1.push_back(2);
    list1.push_back(3);
    list1.push_back(4);
    list1.push_back(5);
    list1.push_back(6);
    list1.print();
    list1.elementSwap(3);
    list1.print();
    

    forward_list<int> list3;
    forward_list<int> list5 = {9, 8, 7};
    list3.assign({2, 3, 4, 5, 6});
    int i = primeCount(list3);
    cout << "prime number: " << i << endl;
    listCopy(list5, list3);
    for (auto i = list3.begin(); i != list3.end(); ++i){
        cout << *i << " ";
    }
    cout << endl;
    
    forward_list<int> list4 = {1, 2, 4};
    printLots(list3, list4);
    
    return 0;
}